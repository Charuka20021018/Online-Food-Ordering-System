package com.ordermanagement.bean;

public class MenuItem {
	protected int itemID;
	protected String itemName;
	protected double itemPrice;
	protected int qty;
	

	public MenuItem() {
		
	}

	public MenuItem(int itemID, String itemName, double itemPrice, int qty) {
		super();
		this.itemID = itemID;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.qty = qty;
	}

	public MenuItem(String itemName, double itemPrice, int qty) {
		super();
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.qty = qty;
	}




	public int getItemID() {
		return itemID;
	}




	public void setItemID(int itemID) {
		this.itemID = itemID;
	}




	public String getItemName() {
		return itemName;
	}




	public void setItemName(String itemName) {
		this.itemName = itemName;
	}




	public double getItemPrice() {
		return itemPrice;
	}




	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}




	public int getQty() {
		return qty;
	}




	public void setQty(int qty) {
		this.qty = qty;
	}
	
	
	
	

}
